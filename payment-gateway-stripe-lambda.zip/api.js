const AWS = require('aws-sdk')
var cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

const { stripeKey, PLAN_IDS } = require('./env');
const stripe = require('stripe')(stripeKey)


let poolData = { 
    UserPoolId : 'us-east-1_xiFKCm1c6',
    ClientId : 'tsvt3ffdmtv8mumsn1rl4ttqp'
};

function generatePassword(length) {
    var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
        retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
    }
function numDapps(plans, typeOfPlan){
    let planName = `custom:${typeOfPlan}_limit`
    return {
        Name:planName,
        Value:'1'
    }
    }
function response(body){
    let responseHeaders = {
        'Content-Type': 'application/json', 
        'Access-Control-Allow-Origin': '*' ,
        'Access-Control-Allow-Headers': 'Authorization,Content-Type',
    }
    return {
        statusCode: 200,
        headers : responseHeaders,
        body : JSON.stringify(body)
    }
}

async function apiCreateCognito(body) {

}

async function apiRead(body) {
    let email = body.email;
    let status = body.status;
    console.log(`Processing Order`)
    console.log("verified body"+ JSON.stringify(body));
        
    //TODO: validate email
    try {
        const user = await cognito.getUser(email);
        return response({
            method: 'read', user
        });
    } catch (err) {
        console.log('Error on getting Cognito User: ',err);
        return response(err);
    }
}

async function apiDelete(body) {
    //TODO: API Delete
}


async function adminSignUp(params){
    return new Promise((resolve, reject) => 
        cognitoidentityserviceprovider.adminCreateUser(params, (err, result) => {
            if (err) {
                reject(err)
                return;
            }
            resolve(result);
        })
    )
}

async function returnPromise(functionCall, params) {
    return new Promise((resolve, reject) => 
        functionCall(params, (err, result) => {
            if (err) {
                reject(err)
                return
            }
            resolve(result)
        })
    )
}

async function apiPaymentFailed(body) {
    const {data} = JSON.parse(body)
    const customer = data.object.customer
    const username = data.object.customer_email


}

async function apiCreateStripe(body) {
    const {  email, plans, name, coupon, token } = JSON.parse(body);

    console.log("Processing order:" , body)
    try {
        console.log("customer creation")
        let customer = await stripe.customers.create({
            description: `customer for ${email}`,
            email: email,
            source: token.id,
            items:[]
          })
        let items = []
        for(let i=0; i<plans.length; i++){
            let planType = Object.keys(plans[i])[0]
            items.push({
                plan:planType,
                quantity: parseInt(plans[i][planType])
            })
        }

        console.log("subscription creation")
        let subscription = await stripe.subscriptions.create({
            customer: customer.id,
            items:items
        })
        console.log(subscription.status)
        if(!subscription.status==="active"){
            throw Error(`Subscription failed because subscription status is ${subscription.status}`)
        }
    
        
        let dataEmail = {
            Name : 'email',
            Value : `${email}`
        };
        
        let params = {
            UserPoolId: poolData.UserPoolId,
            Username: email,
            DesiredDeliveryMediums: [
                "EMAIL"
            ],
            ForceAliasCreation:false,
            TemporaryPassword: generatePassword(10),
            UserAttributes:[
                dataEmail,
                {
                    Name: 'email_verified',
                    Value: 'true'
                },
                numDapps(plans,"standard"),
                numDapps(plans, "enterprise"),
                numDapps(plans, "professional"),
            ]
        }


        console.log("creating cognito user")
        console.log("params: ", params)
        // console.log("attribute list: ", attributeList)

        let result = await adminSignUp(params)
        // let result = await signUp(userPool, email, generatePassword(10), attributeList)
        // await userPool.signUp(email, generatePassword(10) , attributeList, null, function(err, result) {
        // console.log("RESULT: ",result)
        // if (err) {
        //     console.log(err.message || JSON.stringify(err));
        //     return;
        // }
        // })

        return response({
            method : 'create-stripe',
            success : true,
            customerId : customer.id,
            subscriptionId : subscription.id
        })
    } catch (err) {
        console.log('Error on Stripe Customer/Subscription create: ',err);
        return response({
            method : 'create-stripe',
            success : false, err
        });
    } 
}

module.exports = {
  createCognito : apiCreateCognito,
  read : apiRead,
  delete : apiDelete,
  createStripe : apiCreateStripe
}