"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var aws_sdk_1 = __importDefault(require("aws-sdk"));
// Provided automagically by AWS
exports.awsRegion = process.env.AWS_REGION;
// Provided by Terraform
exports.cognitoUserPoolId = process.env.COGNITO_USER_POOL;
exports.stripeKey = process.env.STRIPE_API_KEY;
exports.stripeWebhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
exports.snsTopicARN = process.env.SNS_TOPIC_ARN;
exports.PLAN_IDS = {
    ENTHUSIAST: '',
    PROJECT: '',
    STARTUP: ''
};
aws_sdk_1.default.config.update({ region: exports.awsRegion });
exports.AWS = aws_sdk_1.default;
exports.default = {
    AWS: exports.AWS, awsRegion: exports.awsRegion, cognitoUserPoolId: exports.cognitoUserPoolId, stripeKey: exports.stripeKey, PLAN_IDS: exports.PLAN_IDS,
    stripeWebhookSecret: exports.stripeWebhookSecret, snsTopicARN: exports.snsTopicARN
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52LmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVudi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUNBLG9EQUFzQztBQUV0QyxnQ0FBZ0M7QUFDbkIsUUFBQSxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7QUFFaEQsd0JBQXdCO0FBQ1gsUUFBQSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUEyQixDQUFDO0FBQzVELFFBQUEsU0FBUyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBd0IsQ0FBQztBQUNqRCxRQUFBLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQStCLENBQUM7QUFDbEUsUUFBQSxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUF1QixDQUFDO0FBRWxELFFBQUEsUUFBUSxHQUFHO0lBQ3BCLFVBQVUsRUFBRyxFQUFFO0lBQ2YsT0FBTyxFQUFHLEVBQUU7SUFDWixPQUFPLEVBQUcsRUFBRTtDQUNmLENBQUE7QUFFRCxpQkFBZSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxNQUFNLEVBQUUsaUJBQVMsRUFBQyxDQUFDLENBQUM7QUFDdEMsUUFBQSxHQUFHLEdBQUcsaUJBQWUsQ0FBQztBQUduQyxrQkFBZTtJQUNYLEdBQUcsYUFBQSxFQUFFLFNBQVMsbUJBQUEsRUFBRSxpQkFBaUIsMkJBQUEsRUFBRSxTQUFTLG1CQUFBLEVBQUUsUUFBUSxrQkFBQTtJQUN0RCxtQkFBbUIsNkJBQUEsRUFBRSxXQUFXLHFCQUFBO0NBQ25DLENBQUMifQ==