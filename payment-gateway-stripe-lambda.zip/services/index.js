module.exports = {
  cognito: require('./cognito'),
  stripe : require('./stripe'),
  sns : require('./sns')
}