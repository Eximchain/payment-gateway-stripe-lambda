"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var stripe_1 = __importDefault(require("stripe"));
exports.stripe = new stripe_1.default(env_1.stripeKey);
function createCustomerAndSubscription(_a) {
    var name = _a.name, email = _a.email, token = _a.token, plans = _a.plans, coupon = _a.coupon;
    return __awaiter(this, void 0, void 0, function () {
        var newCustomer, newSub;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.create({
                        name: name, email: email,
                        description: "Customer for " + email,
                        source: token
                    })];
                case 1:
                    newCustomer = _b.sent();
                    return [4 /*yield*/, exports.stripe.subscriptions.create({
                            customer: newCustomer.id,
                            items: plans.map(function (planObj) {
                                var planType = Object.keys(planObj)[0];
                                return {
                                    plan: planType,
                                    quantity: planObj[planType]
                                };
                            })
                        })];
                case 2:
                    newSub = _b.sent();
                    return [2 /*return*/, {
                            customer: newCustomer,
                            subscription: newSub
                        }];
            }
        });
    });
}
function updateStripeSubscription(email, newPlans) {
    return __awaiter(this, void 0, void 0, function () {
        var subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeSubscriptionByEmail(email)];
                case 1:
                    subscription = _a.sent();
                    if (!subscription) {
                        throw new Error("Unable to update subscription for email " + email + ", no subscriptions exist.");
                    }
                    return [4 /*yield*/, exports.stripe.subscriptions.update(subscription.id, {
                            items: newPlans.map(function (planObj) {
                                var planType = Object.keys(planObj)[0];
                                return {
                                    plan: planType,
                                    quantity: planObj[planType]
                                };
                            })
                        })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getStripeCustomer(email) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.list({ email: email })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Two customers with same email!");
                    }
                    return [2 /*return*/, matchingList.data[0]];
            }
        });
    });
}
function getStripeSubscription(stripeCustomerId) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.subscriptions.list({
                        customer: stripeCustomerId
                    })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Customer has more than one subscription, sign of an error.");
                    }
                    return [2 /*return*/, matchingList.data[0]];
            }
        });
    });
}
function getStripeSubscriptionByEmail(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) {
                        return [2 /*return*/, null];
                    }
                    return [4 /*yield*/, getStripeSubscription(customer.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function cancelStripeSubscription(email) {
    return __awaiter(this, void 0, void 0, function () {
        var subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeSubscriptionByEmail(email)];
                case 1:
                    subscription = _a.sent();
                    if (!subscription) {
                        throw new Error("Unable to cancel subscription for " + email + ", no subscription exists.");
                    }
                    return [4 /*yield*/, exports.stripe.subscriptions.del(subscription.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getStripeData(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer, subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) return [3 /*break*/, 3];
                    return [4 /*yield*/, getStripeSubscription(customer.id)];
                case 2:
                    subscription = _a.sent();
                    _a.label = 3;
                case 3: return [2 /*return*/, { customer: customer, subscription: subscription }];
            }
        });
    });
}
exports.default = {
    create: createCustomerAndSubscription,
    update: updateStripeSubscription,
    cancel: cancelStripeSubscription,
    read: getStripeData,
    stripe: exports.stripe
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RyaXBlLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL3N0cmlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsOEJBQTZDO0FBQzdDLGtEQUE0QjtBQUNmLFFBQUEsTUFBTSxHQUFHLElBQUksZ0JBQU0sQ0FBQyxlQUFTLENBQUMsQ0FBQztBQW1CNUMsU0FBZSw2QkFBNkIsQ0FBQyxFQUFzRDtRQUFwRCxjQUFJLEVBQUUsZ0JBQUssRUFBRSxnQkFBSyxFQUFFLGdCQUFLLEVBQUUsa0JBQU07Ozs7O3dCQUMxRCxxQkFBTSxjQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQzt3QkFDaEQsSUFBSSxNQUFBLEVBQUUsS0FBSyxPQUFBO3dCQUNYLFdBQVcsRUFBRSxrQkFBZ0IsS0FBTzt3QkFDcEMsTUFBTSxFQUFFLEtBQUs7cUJBQ2QsQ0FBQyxFQUFBOztvQkFKSSxXQUFXLEdBQUcsU0FJbEI7b0JBQ2EscUJBQU0sY0FBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7NEJBQy9DLFFBQVEsRUFBRSxXQUFXLENBQUMsRUFBRTs0QkFDeEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsVUFBQyxPQUFPO2dDQUN2QixJQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN6QyxPQUFPO29DQUNMLElBQUksRUFBRSxRQUFRO29DQUNkLFFBQVEsRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDO2lDQUM1QixDQUFBOzRCQUNILENBQUMsQ0FBQzt5QkFDSCxDQUFDLEVBQUE7O29CQVRJLE1BQU0sR0FBRyxTQVNiO29CQUNGLHNCQUFPOzRCQUNMLFFBQVEsRUFBRSxXQUFXOzRCQUNyQixZQUFZLEVBQUUsTUFBTTt5QkFDckIsRUFBQTs7OztDQUNGO0FBRUQsU0FBZSx3QkFBd0IsQ0FBQyxLQUFZLEVBQUUsUUFBcUI7Ozs7O3dCQUNwRCxxQkFBTSw0QkFBNEIsQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQXhELFlBQVksR0FBRyxTQUF5QztvQkFDOUQsSUFBSSxDQUFDLFlBQVksRUFBQzt3QkFDaEIsTUFBTSxJQUFJLEtBQUssQ0FBQyw2Q0FBMkMsS0FBSyw4QkFBMkIsQ0FBQyxDQUFDO3FCQUM5RjtvQkFDTSxxQkFBTSxjQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFOzRCQUN4RCxLQUFLLEVBQUUsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFDLE9BQU87Z0NBQzFCLElBQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pDLE9BQU87b0NBQ0wsSUFBSSxFQUFFLFFBQVE7b0NBQ2QsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUM7aUNBQzVCLENBQUE7NEJBQ0gsQ0FBQyxDQUFDO3lCQUNILENBQUMsRUFBQTt3QkFSRixzQkFBTyxTQVFMLEVBQUE7Ozs7Q0FDSDtBQUVELFNBQWUsaUJBQWlCLENBQUMsS0FBWTs7Ozs7d0JBQ3RCLHFCQUFNLGNBQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFBLEVBQUUsQ0FBQyxFQUFBOztvQkFBckQsWUFBWSxHQUFHLFNBQXNDO29CQUUzRCxJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDbEMsc0JBQU8sSUFBSSxFQUFDO3FCQUNiO3lCQUFNLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO3dCQUN2QyxNQUFNLElBQUksS0FBSyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7cUJBQ25EO29CQUVELHNCQUFPLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUM7Ozs7Q0FDN0I7QUFFRCxTQUFlLHFCQUFxQixDQUFDLGdCQUF1Qjs7Ozs7d0JBQ3JDLHFCQUFNLGNBQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO3dCQUNuRCxRQUFRLEVBQUUsZ0JBQWdCO3FCQUMzQixDQUFDLEVBQUE7O29CQUZJLFlBQVksR0FBRyxTQUVuQjtvQkFFRixJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDbEMsc0JBQU8sSUFBSSxFQUFDO3FCQUNiO3lCQUFNLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO3dCQUN2QyxNQUFNLElBQUksS0FBSyxDQUFDLDREQUE0RCxDQUFDLENBQUM7cUJBQy9FO29CQUVELHNCQUFPLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUM7Ozs7Q0FDN0I7QUFFRCxTQUFlLDRCQUE0QixDQUFDLEtBQVk7Ozs7O3dCQUNyQyxxQkFBTSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQXpDLFFBQVEsR0FBRyxTQUE4QjtvQkFDL0MsSUFBSSxDQUFDLFFBQVEsRUFBQzt3QkFDWixzQkFBTyxJQUFJLEVBQUM7cUJBQ2I7b0JBQ00scUJBQU0scUJBQXFCLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFBO3dCQUEvQyxzQkFBTyxTQUF3QyxFQUFDOzs7O0NBQ2pEO0FBRUQsU0FBZSx3QkFBd0IsQ0FBQyxLQUFZOzs7Ozt3QkFDN0IscUJBQU0sNEJBQTRCLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUF4RCxZQUFZLEdBQUcsU0FBeUM7b0JBQzlELElBQUksQ0FBQyxZQUFZLEVBQUM7d0JBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUNBQXFDLEtBQUssOEJBQTJCLENBQUMsQ0FBQTtxQkFDdkY7b0JBQ00scUJBQU0sY0FBTSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxFQUFBO3dCQUF0RCxzQkFBTyxTQUErQyxFQUFBOzs7O0NBQ3ZEO0FBRUQsU0FBZSxhQUFhLENBQUMsS0FBWTs7Ozs7d0JBRTVCLHFCQUFNLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBekMsUUFBUSxHQUFHLFNBQThCLENBQUM7eUJBQ3RDLFFBQVEsRUFBUix3QkFBUTtvQkFDSyxxQkFBTSxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUE7O29CQUF2RCxZQUFZLEdBQUcsU0FBd0MsQ0FBQzs7d0JBRTFELHNCQUFPLEVBQUUsUUFBUSxVQUFBLEVBQUUsWUFBWSxjQUFBLEVBQUUsRUFBQzs7OztDQUNuQztBQUVELGtCQUFlO0lBQ2IsTUFBTSxFQUFFLDZCQUE2QjtJQUNyQyxNQUFNLEVBQUUsd0JBQXdCO0lBQ2hDLE1BQU0sRUFBRSx3QkFBd0I7SUFDaEMsSUFBSSxFQUFFLGFBQWE7SUFDbkIsTUFBTSxnQkFBQTtDQUNQLENBQUEifQ==